
#ifndef ITOS_EXP1_COMMON_H
#define ITOS_EXP1_COMMON_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <fcntl.h>
#include <unistd.h>

#include <sys/wait.h>
#include <sys/file.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/types.h>

#define NULL 0

#endif //ITOS_EXP1_COMMON_H
